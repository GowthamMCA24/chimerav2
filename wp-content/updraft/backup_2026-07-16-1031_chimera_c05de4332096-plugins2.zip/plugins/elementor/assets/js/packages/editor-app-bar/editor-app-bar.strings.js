__( 'Exit to WordPress', 'elementor' );
__( 'Send Feedback', 'elementor' );
__( 'Angie', 'elementor' );
__(
	'Angie lets you generate custom widgets, sections, and code using simple instructions.',
	'elementor'
);
__( 'Build custom widgets using simple instructions.', 'elementor' );
__( 'More', 'elementor' );
__( 'Elementor Logo', 'elementor' );
__( 'Submit Feedback', 'elementor' );
__(
											'E.g. Can you add ABC features? I want to do ABC and it’s important because …',
											'elementor'
										);
__( 'Your Feedback', 'elementor' );
__( 'Submit Another Feedback', 'elementor' );
__( 'Submit', 'elementor' );
__( 'Connect to Elementor', 'elementor' );
__( 'Integrations', 'elementor' );
__( 'User Preferences', 'elementor' );
__( 'Theme Builder', 'elementor' );
__( 'Structure', 'elementor' );
__( 'Site Settings', 'elementor' );
__( 'Save Changes', 'elementor' );
__( 'Switch Device', 'elementor' );
// translators: %s: Breakpoint label, %d: Breakpoint size.
__( '%s (%dpx and up)', 'elementor' );
// translators: %s: Breakpoint label, %d: Breakpoint size.
__( '%s (up to %dpx)', 'elementor' );
__( 'Keyboard Shortcuts', 'elementor' );
__( 'History', 'elementor' );
__( 'Help Center', 'elementor' );
__( 'Finder', 'elementor' );
__( 'Elements', 'elementor' );
__( 'Widgets', 'elementor' );
__( 'Add Element', 'elementor' );
/* translators: %s: Post type label. */
__( '%s Settings', 'elementor' );
__( 'Document Settings', 'elementor' );
__( 'View Page', 'elementor' );
__( 'View as Markdown', 'elementor' );
__( 'Save as Template', 'elementor' );
__( 'Save Draft', 'elementor' );
__( 'Copy and Share', 'elementor' );
__( 'Save Options', 'elementor' );
__( 'Save Options', 'elementor' );
__( 'Publish', 'elementor' );
__( 'Submit', 'elementor' );
__( 'Preview Changes', 'elementor' );
__( 'My Elementor', 'elementor' );
__( 'Connect my account', 'elementor' );
__( 'Angie', 'elementor' );
__( 'Meet Angie', 'elementor' );
__( 'New', 'elementor' );
__( 'Angie', 'elementor' );
__( 'Learn More', 'elementor' );
__( 'Try for free', 'elementor' );