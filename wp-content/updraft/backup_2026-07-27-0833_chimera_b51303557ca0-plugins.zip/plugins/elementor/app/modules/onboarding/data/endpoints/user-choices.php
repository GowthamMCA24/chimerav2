<?php

namespace Elementor\App\Modules\Onboarding\Data\Endpoints;

use Elementor\App\Modules\Onboarding\Storage\Onboarding_Progress_Manager;
use Elementor\App\Modules\Onboarding\Validation\User_Choices_Validator;
use Elementor\Data\V2\Base\Endpoint as Endpoint_Base;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class User_Choices extends Endpoint_Base {

	public function get_name(): string {
		return 'user-choices';
	}

	public function get_format(): string {
		return 'onboarding';
	}

	protected function register(): void {
		parent::register();

		$this->register_items_route( WP_REST_Server::EDITABLE );
	}

	public function get_items( $request ) {
		$permission = $this->check_permission();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$manager = Onboarding_Progress_Manager::instance();
		$choices = $manager->get_choices();

		return [
			'data' => $choices->to_array(),
		];
	}

	public function update_items( $request ) {
		$permission = $this->check_permission();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$params = $request->get_json_params();

		$validator = new User_Choices_Validator();
		$validated = $validator->validate( $params ?? [] );

		if ( is_wp_error( $validated ) ) {
			return $validated;
		}

		$manager = Onboarding_Progress_Manager::instance();
		$choices = $manager->update_choices( $validated );

		return [
			'data' => 'success',
			'choices' => $choices->to_array(),
		];
	}

	private function check_permission() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'rest_forbidden',
				__( 'Sorry, you are not allowed to access onboarding data.', 'elementor' ),
				[ 'status' => 403 ]
			);
		}
		return true;
	}
}
