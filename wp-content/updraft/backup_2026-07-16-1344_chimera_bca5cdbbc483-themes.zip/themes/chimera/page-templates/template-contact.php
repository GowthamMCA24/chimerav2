<?php
/**
 * Template Name: Contact Page
 * 
 * Content is driven by Secure Custom Fields (SCF/ACF) and Contact Form 7.
 *
 * @package Chimera
 */

get_header();
$Herosection = get_field('herosection');
$badge = $Herosection['badge'];
$heading = $Herosection['heading'];
$description = $Herosection['description'];
$benefits = $Herosection['benefits'] ?? [];
$contact_form_shortcode = $Herosection['contact_form_shortcode'] ?? [];

?>

<main id="primary" class="site-main bg-[#f9f7f6] min-h-screen overflow-hidden -mt-[80px] pt-[80px]">

    <section class="relative pb-[50px] pt-[50px]">
        <div class="container">
            <div class="flex flex-col lg:flex-row gap-[62px] items-center">

                <!-- Left Content -->
                <div class="w-full lg:w-1/2 flex flex-col gap-[40px]">

                    <div class="flex flex-col gap-[8px]">
                        <div class="w-max">
                            <h3
                                class="inline-flex font-jost items-center justify-center px-4 py-1.5 bg-white border border-orangeBorder rounded-[8px] text-xs font-semibold uppercase text-orange tracking-wider mb-5">
                                <?php echo esc_html($badge); ?>
                            </h3>
                        </div>
                        <h1
                            class="text-dark max-w-xl text-[36px] lg:text-[40px] font-jost font-semibold leading-[1.2] tracking-[-0.12px]">
                            <?php echo wp_kses_post($heading); ?>
                        </h1>
                    </div>

                    <div class="flex flex-col gap-[17px]">
                        <p class="text-gray text-[18px] font-sans font-normal leading-[1.5]">
                            <?php echo esc_html($description); ?>
                        </p>


                        <ul class="flex flex-col gap-[14px]">
                            <?php foreach ($benefits as $benefit): ?>
                                <li class="flex items-start gap-[4px]">
                                    <div class="w-[32px] h-[30px] flex-shrink-0 flex items-center justify-center">
                                        <img src="<?php echo esc_url($benefit['icon']['url']); ?>" alt="">
                                    </div>
                                    <p class="text-gray font-normal text-[18px] font-sans leading-[1.5]">
                                        <?php echo wp_kses_post($benefit['text']); ?>
                                    </p>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                    <!-- Trusted Logos Reusable Section -->
                    <div class="w-full">
                        <?php get_template_part('template-parts/home/logocarousel', null, [
                            'bg_color' => 'bg-transparent',
                            'gradient_from' => 'from-[#f9f7f6]',
                            'heading_align' => 'text-left'
                        ]); ?>
                    </div>
                </div>

                <!-- Right Form Container -->
                <div class="w-full lg:w-1/2 relative mt-10 lg:mt-0">
                    <!-- Orange outer card matching Figma -->
                    <div class="relative w-full rounded-[24px] overflow-hidden min-h-[600px] bg-orange-gradient lg:min-h-[820px] flex flex-col justify-center px-[20px] py-[40px] lg:px-[54px] lg:py-[50px] bg-[linear-gradient(0deg,rgba(255,255,255,0.2),rgba(255,255,255,0.2)),linear-gradient(180deg,rgba(255,74,3,0.1)_66.83%,rgba(255,255,255,0)_100%)]"
                        >

                        <!-- White Form Card -->
                        <div class="relative z-10 bg-white rounded-[12px] w-full contact-form-wrapper"
                            style="padding: 40px; border: 1px solid #f2ecff;">
                            <?php
                            if ($contact_form_shortcode) {
                                echo do_shortcode($contact_form_shortcode);
                            } else {
                                echo '<p style="color:#666;font-family:sans-serif;">Please add the Contact Form 7 shortcode via the page editor fields.</p>';
                            }
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

</main>

<style>
    /* ── Contact Form 7 — Figma-accurate styles ── */
    @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500&display=swap');

    /* The CF7 form itself */
    .contact-form-wrapper .wpcf7 {
        width: 100%;
    }
    .contact-form-wrapper .wpcf7-form {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    /* Label rows — stacked above input */
    .contact-form-wrapper label {
        display: flex;
        flex-direction: column;
        gap: 4px;
        font-family: 'IBM Plex Sans', sans-serif;
        font-weight: 500;
        font-size: 16px;
        color: #6f7482;
        line-height: 1.5;
        margin: 0;
    }

    /* control-wrap fills full width */
    .contact-form-wrapper .wpcf7-form-control-wrap {
        display: block;
        width: 100%;
    }

    /* Inputs & Textarea */
    .contact-form-wrapper input[type="text"],
    .contact-form-wrapper input[type="email"],
    .contact-form-wrapper input[type="tel"],
    .contact-form-wrapper textarea {
        display: block;
        width: 100%;
        background-color: #f8fafc;
        border: 1.5px solid #f8fafc;
        border-radius: 4px;
        padding: 12px;
        color: #3b4256;
        font-family: 'IBM Plex Sans', sans-serif;
        font-size: 16px;
        font-weight: 400;
        line-height: 1.5;
        letter-spacing: 0.01em;
        transition: border-color 0.2s ease;
        outline: none;
    }

    .contact-form-wrapper input[type="text"]::placeholder,
    .contact-form-wrapper input[type="email"]::placeholder,
    .contact-form-wrapper input[type="tel"]::placeholder,
    .contact-form-wrapper textarea::placeholder {
        color: #b8bcca;
        font-weight: 400;
    }

    .contact-form-wrapper input[type="text"]:focus,
    .contact-form-wrapper input[type="email"]:focus,
    .contact-form-wrapper input[type="tel"]:focus,
    .contact-form-wrapper textarea:focus {
        border-color: #ff4a03;
        background-color: #fff;
        box-shadow: 0 0 0 3px rgba(255, 74, 3, 0.08);
    }

    /* Textarea height — controlled via rows="" in CF7 shortcode */
    .contact-form-wrapper textarea {
        min-height: unset;
        height: auto;
        resize: vertical;
    }

    /* Acceptance (checkbox) row */
    .contact-form-wrapper .wpcf7-acceptance {
        margin: 4px 0;
    }
    .contact-form-wrapper .wpcf7-acceptance label {
        display: flex;
        flex-direction: row;
        align-items: flex-start;
        gap: 10px;
        margin: 0;
    }
    .contact-form-wrapper .wpcf7-acceptance input[type="checkbox"] {
        flex-shrink: 0;
        width: 20px;
        height: 20px;
        margin-top: 2px;
        accent-color: #ff4a03;
        cursor: pointer;
        border-radius: 4px;
    }
    .contact-form-wrapper .wpcf7-acceptance .wpcf7-list-item-label {
        font-family: 'IBM Plex Sans', sans-serif;
        font-size: 14px;
        font-weight: 400;
        color: #b8bcca;
        line-height: 1.5;
    }
    /* Orange link inside acceptance text */
    .contact-form-wrapper .wpcf7-acceptance .wpcf7-list-item-label a {
        color: #ff4a03;
        text-decoration: none;
    }
    .contact-form-wrapper .wpcf7-acceptance .wpcf7-list-item-label a:hover {
        text-decoration: underline;
    }

    /* Submit button — full width, orange, 48px */
    .contact-form-wrapper input[type="submit"],
    .contact-form-wrapper .wpcf7-submit {
        display: block;
        width: 100%;
        height: 48px;
        background-color: #ff4a03;
        color: #ffffff;
        font-family: 'IBM Plex Sans', sans-serif;
        font-weight: 500;
        font-size: 18px;
        text-align: center;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: background-color 0.2s ease;
        margin-top: 4px;
        letter-spacing: 0.01em;
    }
    .contact-form-wrapper input[type="submit"]:hover,
    .contact-form-wrapper .wpcf7-submit:hover {
        background-color: #e03f00;
    }

    /* Validation error messages */
    .contact-form-wrapper .wpcf7-not-valid-tip {
        font-family: 'IBM Plex Sans', sans-serif;
        font-size: 13px;
        color: #e03f00;
        margin-top: 4px;
        display: block;
    }
    .contact-form-wrapper .wpcf7-not-valid {
        border-color: #e03f00 !important;
    }
    .contact-form-wrapper .wpcf7-response-output {
        font-family: 'IBM Plex Sans', sans-serif;
        font-size: 14px;
        border-radius: 6px;
        padding: 10px 14px;
        margin-top: 8px;
        border: none;
    }
    .contact-form-wrapper .wpcf7-mail-sent-ok {
        background-color: #f0fff4;
        color: #276749;
    }
    .contact-form-wrapper .wpcf7-mail-sent-ng,
    .contact-form-wrapper .wpcf7-aborted,
    .contact-form-wrapper .wpcf7-validation-errors {
        background-color: #fff5f5;
        color: #c53030;
    }
</style>

<?php
get_footer();
